package Enuns;

public enum TipoCerveja {
    IPA, STOUT, PILSEN, WEISS
}
