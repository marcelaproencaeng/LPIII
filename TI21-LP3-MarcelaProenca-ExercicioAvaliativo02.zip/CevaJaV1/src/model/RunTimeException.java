package model;

public class RunTimeException extends Exception {
    public RunTimeException(String mensagem) {
        super(mensagem);

    }
}
