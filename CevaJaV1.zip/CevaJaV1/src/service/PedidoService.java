package service;

import model.Pedido;

public class PedidoService {


    PedidoService efetuarPedidoServece=new PedidoService();



    public void efetuarPedido(Pedido pedido1) {
    }
}


