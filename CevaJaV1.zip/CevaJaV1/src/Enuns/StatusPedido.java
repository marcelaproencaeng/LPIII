package Enuns;

public enum StatusPedido {


    CRIADO, ACEITO, EM_PREPARO, CAMINHO, DISPONIVEL_RETIRADA, ENTREGUE
}
