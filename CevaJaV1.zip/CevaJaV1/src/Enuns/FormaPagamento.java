package Enuns;

public enum FormaPagamento {
    DINHEIRO, PIX, CARTAO

}
